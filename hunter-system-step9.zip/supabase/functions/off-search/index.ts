// supabase/functions/off-search/index.ts
//
// Deploy the same way as macro-chat: Supabase Dashboard → Edge Functions →
// Deploy a new function → Via Editor → name it "off-search" → paste this in.
// No secrets needed — Open Food Facts' search doesn't require an API key.
//
// Why this exists: Open Food Facts' search-a-licious endpoint
// (search.openfoodfacts.org) doesn't send Access-Control-Allow-Origin,
// so browsers block it when called directly from a web app. Server-to-server
// calls (like this Edge Function) aren't subject to that browser restriction,
// so this proxy gives the app real access to OFF's full 3M+ product catalog.

import { serve } from 'https://deno.land/std@0.192.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { query } = await req.json();
    if (!query || typeof query !== 'string' || !query.trim()) {
      return new Response(JSON.stringify({ results: [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const url = `https://search.openfoodfacts.org/search?q=${encodeURIComponent(query.trim())}&page_size=8`;
    const res = await fetch(url);

    if (!res.ok) {
      return new Response(JSON.stringify({ error: 'Open Food Facts search failed', status: res.status }), {
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await res.json();

    const results = (data.hits || [])
      .filter((p) => p.product_name && p.nutriments)
      .map((p) => {
        const brand = Array.isArray(p.brands) ? p.brands[0] : (typeof p.brands === 'string' ? p.brands : null);
        return {
          name: brand ? `${p.product_name} (${brand})` : p.product_name,
          calories: Math.round(p.nutriments['energy-kcal_100g'] || 0),
          protein: Math.round((p.nutriments['proteins_100g'] || 0) * 10) / 10,
          carbs: Math.round((p.nutriments['carbohydrates_100g'] || 0) * 10) / 10,
          fat: Math.round((p.nutriments['fat_100g'] || 0) * 10) / 10
        };
      });

    return new Response(JSON.stringify({ results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
